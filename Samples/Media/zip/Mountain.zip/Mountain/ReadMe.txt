This skybox is freeware. A gift to the independant video game development community.

There are no restrictions to its use.

You dont have to credit me - although it would be nice.

The asset is free, but it remains the intellectual property of
Octane Digital Studios Ltd.

Copyright 2004 Octane Digital Studios.


Cheers.













