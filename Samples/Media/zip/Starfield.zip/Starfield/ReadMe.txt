SKY ZONES

If you want to make your own cube mesh and apply the textures
yourself, then open the 'Textures' folder and select from either 
High Resolution or Low Resolution textures.

The lowest resolution images are 256x256 (8 bit colour depth). These files
are saved with the (.pcx) extension.

If you just want to import a ready-made mesh, then open the 
'Sky Zone Mesh' folder.


TIP No.1 **************************

 MAKE A BACK UP COPY OF SKY ZONES
 BEFORE YOU START WORKING WITH THE
 FILES

***********************************


TIP No.2 **************************

 IF YOUR LEVEL EDITOR DOESN'T IMPORT
 THE TEXTURES CORRECTLY, IT'S EITHER
 THE DIMENSIONS OF THE TEXURE, OR THE
 COLOUR DEPTH.

 USE PHOTOSHOP OR PAINTSHOP PRO TO
 REDUCE COLOURS and\or RESIZE.

***********************************


These resources are free for commercial and non-commercial use.
In other words, they are royalty-free. Use them wherever and whenever you want, 
but DO NOT RE-SELL THEM.

Example,

Acceptable Uses:

	Video Game Production
	Level Editing - Custom Maps, texture packs etc
	CGI for Motion Pictures
	Television (Broadcasting)
	Web page design 

Unacceptable Uses:

	Texture Compilation CDs - without prior consent
	Web Sites that distribute textures for free - without prior consent

If you have any questions then email them to: 

technical@OctaneDigitalStudios.com

ENJOY

Copyright 2004 Octane Digital Studios Ltd. All Rights Reserved.
Octane Digital Studios Ltd is registered in the United Kingdom.
Company number: 4652153




 




